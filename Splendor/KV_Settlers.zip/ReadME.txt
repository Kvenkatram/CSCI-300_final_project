**************************
In Order to Build the Game, make sure all the images are in the resource foulder
	-if not to add
	-right click on the resource file and click add existing directory 
	- add the file names images


**************************
**************************
RULES

Goal: get 15 victory points

On Your Turn: do one of the following actions
	-take 3 of the same gem
	-take 3 different gems
	-spend gems on a development card
	-impress a noble
	-reserve a card

Buying cards:
	The base cost of each card is printed on its face
	VP gained from buying the card are listed in the top right corner
	The background of the card tells the player what gem bonus they will get for buying that card
	
	bonuses make the price of cards cheeper 
	ex. buy a card with a bonus for ruby
		now when a player goes to buy a card that requires rubies, 
		the price is reduced by 1
	*bonuses stack throught the game ie. it is possible to get cards for free

Impressing nobles:
	the numbers listed on the noble cards show how many bonuses of each type a player
	needs to get the card
	
	ex. if a card has 3 blue and 3 green
		then the player needs to have bought 3 cards that give a sapphire bonus
		and 3 cards that give an emerald bonus to take the card

Reserving a card:
	a player can reserve 1 card at any time. 
	
	a reserved card is taken off the board and can be bought only by that player at
	a later time